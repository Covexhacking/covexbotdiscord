const { MessageEmbed, Formatters } = require('discord.js');
const config = require("../config.json");

const atualizarEmbedQtdProduto = (nome, qtd = 1) => (

    new MessageEmbed()
    .setColor(config.color)
    .setAuthor({name: `Produto: ${nome}`})
        .setDescription(`**Quantidade que quer comprar -->** \`${qtd}\`\n💰Quer Adiconar Mais produtos na sua compra? use os botões abaixo para escolher a quantia que você quer!!!💎 

**Clicando em "+" para adicionar mais Produtos**
**Clicando em "-" para remover quantidade do produto**

__Boa Compra!__`)
);

module.exports = { atualizarEmbedQtdProduto };
